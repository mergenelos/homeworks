
n.n.n / 2014-04-26 
==================

 * finished ALUF theme and remove logos
 * trivial fixes in readme and ignore file
 * more re-structuring and better readme
 * ignore file
 * better namings
 * re-structuring things
 * Update README.md
 * Update README.md
 * minor readme update
 * initial push
 * readme
